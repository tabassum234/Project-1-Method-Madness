// Tabassum Bhuiyan Period 2 Runner Class
public class Runner
{
	public static void main (String []args)
	{
		int check = 0;
		System.out.println(TBhuiyanLib.isFibonacci(check));
		String word2 = "null";
		String word = "null";
		System.out.println(TBhuiyanLib.cutOut(word, word2));
		String date = "null";
		System.out.println(TBhuiyanLib.dateStrstring(date));
	}
}